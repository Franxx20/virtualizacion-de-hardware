#!/bin/bash



while :; do
  sleep 1
  ps -T -C ejercicio1
  echo " "
done

